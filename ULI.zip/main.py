import sys
import os
import serial
import serial.tools.list_ports
from PyQt6.QtWidgets import QApplication, QMainWindow
from PyQt6.QtWebEngineWidgets import QWebEngineView
from PyQt6.QtWebChannel import QWebChannel
from PyQt6.QtCore import QUrl, QObject, pyqtSlot, QMetaObject, Qt

class ConsoleRedirector(QObject):
    """Redirects Python stdout/stderr to the JavaScript console safely."""
    def __init__(self, browser_widget):
        super().__init__()
        self.browser = browser_widget
        self._is_redirecting = False

    def write(self, message):
        # Filter out empty messages and prevent recursion
        if message.strip() and not self._is_redirecting:
            self._is_redirecting = True
            try:
                # Escape the message for JS
                safe_msg = message.replace("\\", "\\\\").replace("'", "\\'").replace("\n", " ")
                # Safely invoke the JS function on the main GUI thread
                js_code = f"if(window.logToConsole) {{ window.logToConsole('{safe_msg}'); }}"
                self.browser.page().runJavaScript(js_code)
            finally:
                self._is_redirecting = False

    def flush(self):
        pass

class Backend(QObject):
    def __init__(self):
        super().__init__()
        self.blocks_file = "saved_blocks.xml"

    @pyqtSlot(result=list)
    def get_serial_ports(self):
        ports = serial.tools.list_ports.comports()
        return [port.device for port in ports]

    @pyqtSlot(str)
    def execute_python(self, code):
        try:
            # We print to the redirected console
            print("Running Blockly Script...")
            # Persistent globals for the 'ifaces' dictionary
            exec(code, globals())
        except Exception as e:
            print(f"HARDWARE ERROR: {e}")

    @pyqtSlot(str)
    def save_blocks(self, xml_text):
        try:
            with open(self.blocks_file, "w") as f:
                f.write(xml_text)
        except Exception as e:
            print(f"Save Error: {e}")

    @pyqtSlot(result=str)
    def get_saved_blocks(self):
        if os.path.exists(self.blocks_file):
            with open(self.blocks_file, "r") as f:
                return f.read()
        return ""

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("{ULI} Universal Lego Interface - PRO")
        self.setGeometry(100, 100, 1200, 800)

        self.browser = QWebEngineView()
        self.backend = Backend()
        
        self.channel = QWebChannel()
        self.channel.registerObject('backend', self.backend)
        self.browser.page().setWebChannel(self.channel)

        # Redirect Console safely
        self.redirector = ConsoleRedirector(self.browser)
        sys.stdout = self.redirector
        sys.stderr = self.redirector

        curr_dir = os.path.dirname(os.path.abspath(__file__))
        index_path = os.path.join(curr_dir, "index.html")
        self.browser.setUrl(QUrl.fromLocalFile(index_path))

        self.setCentralWidget(self.browser)

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec())